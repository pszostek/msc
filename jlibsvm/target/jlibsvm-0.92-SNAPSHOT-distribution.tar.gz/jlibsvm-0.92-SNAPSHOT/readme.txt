jLibSvm

Efficient training of Support Vector Machines in Java
Modifications from LIBSVM are copyright (c) 2008-2009 David Soergel.

See http://dev.davidsoergel.com/trac/jlibsvm/ for more information.

